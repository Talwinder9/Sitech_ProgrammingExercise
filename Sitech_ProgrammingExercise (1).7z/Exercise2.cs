﻿using System;
using System.IO;
using System.Security.Cryptography;

namespace Sitech_ProgrammingExercise
{
    public partial class MainWindow
    {
        // this method will be called several times with paths to 2 files.
        // the method should return true if the file contents match (files are equal)
        // and false if the file contents do not match.
        public bool Exercise2(string filePath1, string filePath2)
        {
            return false;
        }
    }
}
