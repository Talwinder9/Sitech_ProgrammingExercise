﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitech_ProgrammingExercise
{
    public partial class MainWindow
    {


        /// <summary>
        /// return the passed collection as a distinct collection of names sorted first by frequency of the names and then alphabetically
        /// </summary>
        /// <param name="names"></param>
        /// <returns></returns>
        public IEnumerable<string> Exercise5(IEnumerable<string> names)
        {
            return null;
        }
    }
}
