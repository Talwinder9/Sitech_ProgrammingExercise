﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitech_ProgrammingExercise
{
    public partial class  MainWindow 
    {
        // this method will be called periodically.
        // make the method return a string that contains the number of seconds
        // from the first time the method is called to the current time
        // example: 
        // 1 Second, 2 Seconds, 3 Seconds ect.
        public string Exercise1()
        {
            return null;
        }
    }
}
